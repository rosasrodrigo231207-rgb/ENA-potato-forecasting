# -*- coding: utf-8 -*-
"""
ENA 2014-2025 (INEI) -> series de tiempo del RENDIMIENTO DE PAPA
Procesamiento por etapas (divide y vencerás) para el .sav gigante
(1679 variables, ~3.8 millones de registros) sin reventar la RAM.

Autor: Rodrigo Claudio Rosas Tuni - FINESI UNAP

Requisitos:
    pip install pyreadstat pandas pyarrow xlsxwriter openpyxl

Uso (en orden, desde cmd en la carpeta del .sav):
    python ena_series_etapas.py diccionario  ENA_2014_2024.sav
    python ena_series_etapas.py extraer      ENA_2014_2024.sav
    python ena_series_etapas.py diagnostico
    python ena_series_etapas.py agregar
  opcionales:
    python ena_series_etapas.py buscar  palabra1 palabra2 ...
    python ena_series_etapas.py csv_completo      (las ~35 columnas, todas las filas)
    python ena_series_etapas.py xlsx_por_anio     (lo mismo en Excel, una hoja por año)

Agregar otro año (ej. ENA 2025, que el INEI publica por módulos):
    python ena_series_etapas.py extraer  ruta\\al\\modulo.sav  2025
  (un comando por cada módulo .sav; el año se indica al final). Las partes se
  suman a las que ya existen en partes_parquet; luego se corre "agregar".
  NO vuelvas a extraer ENA_2014_2024.sav o se duplicarán esos años.
"""
import sys
import glob
import os
import re
import numpy as np
import pandas as pd
import pyreadstat

# ---------------------------------------------------------------------------
# CONFIG (nombres verificados en el diccionario de tu ENA_2014_2024)
# ---------------------------------------------------------------------------
CONFIG = {
    "encoding": None,                 # se autodetecta (latin1 en tu archivo)
    "chunksize": 250_000,             # bájalo a 100_000 si tu PC tiene 8 GB de RAM
    "cultivo_regex": r"^PAPA\b",      # PAPA, PAPA BLANCA, PAPA NATIVA... (excluye PAPAYA)
    "resfin_validos": [1],            # 1 = encuesta completa
    "rend_referencia_kg_ha": 15_000,  # orden de magnitud del rendimiento de papa en Perú
    "rend_min_kg_ha": 300,            # filas con rendimiento fuera de este rango se descartan
    "rend_max_kg_ha": 80_000,         # (errores de unidad de medida)
}

COLUMNAS = {
    # identificación / diseño
    "id": ["ANIO", "CCDD", "NOMBREDD", "CCPP", "CCDI", "CONGLOMERADO", "CONGLOME", "NSEGM",
           "NSELUA", "ID_PROD", "UA", "RESFIN", "REGION",
           "FACTOR", "FACTOR_PRODUCTOR", "FACTOR_SUPERFICIE"],
    # nivel cultivo (una fila por cultivo cosechado en cada parcela)
    "cultivo": ["P204_NOM", "P204_COD", "P217_SUP_ha", "P217_SUP_1", "P217_SUP_2",
                "P219_CANT_1", "P219_CANT_2", "P219_EQUIV_KG",
                "P224_CANT_1", "P224_CANT_2", "P224_EQUIV_KG",            # producción (otros años)
                "P229D_CANT_ENT", "P229D_CANT_DEC", "P229D_EQUIV", "P229_EQUIV",
                "P212", "P214", "P220_1_PRE_KG"],
    # nivel productor (se repite en sus filas -> se deduplica)
    "productor": ["P238", "P236", "P704", "P701", "P901", "P902", "P801", "P905",
                  "P224A", "P224E_4", "P224E_7"],
}

DEPARTAMENTOS = {
    "01": "Amazonas", "02": "Áncash", "03": "Apurímac", "04": "Arequipa", "05": "Ayacucho",
    "06": "Cajamarca", "07": "Callao", "08": "Cusco", "09": "Huancavelica", "10": "Huánuco",
    "11": "Ica", "12": "Junín", "13": "La Libertad", "14": "Lambayeque", "15": "Lima",
    "16": "Loreto", "17": "Madre de Dios", "18": "Moquegua", "19": "Pasco", "20": "Piura",
    "21": "Puno", "22": "San Martín", "23": "Tacna", "24": "Tumbes", "25": "Ucayali",
}

DIR_PARTES = "partes_parquet"
DICC_XLSX = "diccionario_variables.xlsx"
SALIDA_SERIES = "series_ENA_papa.xlsx"
LIMITE_XLSX = 1_048_575


# ---------------------------------------------------------------------------
# utilidades
# ---------------------------------------------------------------------------
def _arreglar_texto(s):
    """'AÃ±O' -> 'AÑO' (UTF-8 leído como latin1)."""
    if not isinstance(s, str):
        return s
    try:
        return s.encode("latin1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return s


def _leer_meta(ruta_sav):
    candidatas = [CONFIG["encoding"], "latin1", "cp1252", "utf-8"]
    ultimo = None
    for enc in dict.fromkeys(candidatas):
        try:
            _, meta = pyreadstat.read_sav(ruta_sav, metadataonly=True, encoding=enc)
            CONFIG["encoding"] = enc
            print(f"[info] codificación usada: {enc or 'la del archivo'}")
            return meta
        except pyreadstat.ReadstatError as e:
            ultimo = e
    raise ultimo


def _num(s):
    return pd.to_numeric(s, errors="coerce")


def _partes():
    fs = sorted(glob.glob(os.path.join(DIR_PARTES, "*.parquet")))
    if not fs:
        raise FileNotFoundError("No hay partes. Corre primero: extraer")
    return fs


def _wmean(valor, peso):
    m = valor.notna() & peso.notna()
    return np.nan if peso[m].sum() == 0 else float((valor[m] * peso[m]).sum() / peso[m].sum())


# ---------------------------------------------------------------------------
# ETAPA 0: diccionario (solo metadatos)
# ---------------------------------------------------------------------------
def etapa0_diccionario(ruta_sav, salida=DICC_XLSX):
    meta = _leer_meta(ruta_sav)
    lab = meta.column_names_to_labels
    vvl = meta.variable_value_labels
    dicc = pd.DataFrame({
        "variable": meta.column_names,
        "etiqueta": [_arreglar_texto(lab.get(c, "") or "") for c in meta.column_names],
        "tipo_spss": [meta.original_variable_types.get(c, "") for c in meta.column_names],
        "n_categorias": [len(vvl.get(c, {})) for c in meta.column_names],
        "categorias": [_arreglar_texto(str({k: v for k, v in vvl.get(c, {}).items()}))[:300]
                       if c in vvl else "" for c in meta.column_names],
    })
    dicc.to_excel(salida, index=False)
    print(f"[Etapa 0] {meta.number_columns} variables, {meta.number_rows:,} filas -> {salida}")


def etapa_buscar(palabras, dicc_xlsx=DICC_XLSX):
    dicc = pd.read_excel(dicc_xlsx)
    texto = (dicc["variable"].astype(str) + " " + dicc["etiqueta"].astype(str)).str.lower()
    mask = pd.Series(False, index=dicc.index)
    for p in palabras:
        mask |= texto.str.contains(p.lower(), regex=False)
    with pd.option_context("display.max_rows", 500, "display.max_colwidth", 100):
        print(dicc.loc[mask, ["variable", "etiqueta", "n_categorias"]].to_string(index=False))


# ---------------------------------------------------------------------------
# ETAPA 1 (DIVIDE): leer por bloques solo ~35 columnas
# ---------------------------------------------------------------------------
def etapa1_extraer(ruta_sav, anio=None):
    os.makedirs(DIR_PARTES, exist_ok=True)
    meta = _leer_meta(ruta_sav)
    mapa = {c.upper(): c for c in meta.column_names}
    deseadas = sum(COLUMNAS.values(), [])
    usar = [mapa[c.upper()] for c in deseadas if c.upper() in mapa]
    faltan = [c for c in deseadas if c.upper() not in mapa]
    if faltan:
        print(f"[aviso] no están en este archivo (se crean vacías): {faltan}")
    if "ANIO" in faltan:
        if anio is None:
            raise SystemExit("Este archivo no trae ANIO: indica el año al final, ej.: "
                             "python ena_series_etapas.py extraer modulo.sav 2025")
        print(f"[info] ANIO no viene en el archivo: se usa {anio}")
    if "RESFIN" in faltan:
        print("[info] RESFIN no viene en el archivo: se asume encuesta completa (1)")
    base = re.sub(r"\W+", "_", os.path.splitext(os.path.basename(ruta_sav))[0])
    carpeta = re.sub(r"\W+", "_", os.path.basename(os.path.dirname(os.path.abspath(ruta_sav))))
    prefijo = f"{anio}_{carpeta}_{base}" if anio else base
    n_filas, paso = meta.number_rows, CONFIG["chunksize"]
    total = 0
    for i, ini in enumerate(range(0, n_filas, paso)):       # lectura por bloques propia
        df, _ = pyreadstat.read_sav(ruta_sav, usecols=usar, row_offset=ini, row_limit=paso,
                                    encoding=CONFIG["encoding"])
        df.columns = [c.upper() for c in df.columns]
        for c in faltan:
            df[c.upper()] = np.nan
        if anio is not None:
            df["ANIO"] = _num(df["ANIO"]).fillna(float(anio))
        if "RESFIN" in faltan:
            df["RESFIN"] = 1.0
        # códigos de texto con basura binaria -> solo los dígitos iniciales
        df["CCDD"] = df["CCDD"].astype(str).str.extract(r"^\s*(\d{1,2})")[0].str.zfill(2)
        for c in ["CONGLOMERADO", "CONGLOME", "NSEGM", "NSELUA", "UA", "CCPP", "CCDI"]:
            df[c] = df[c].astype(str).str.extract(r"^\s*(\d+)")[0]
        for c in ["P204_NOM", "NOMBREDD"]:
            df[c] = df[c].map(_arreglar_texto)
        df.to_parquet(os.path.join(DIR_PARTES, f"{prefijo}_{i:04d}.parquet"), index=False)
        total += len(df)
        print(f"[Etapa 1] bloque {i:4d}: {len(df):>9,} filas (acum. {total:,})")
    print(f"[Etapa 1] listo: {total:,} filas, {len(usar)} columnas -> {DIR_PARTES}/")


# ---------------------------------------------------------------------------
# ETAPA 2: diagnóstico (cobertura por año, RESFIN, cultivos detectados)
# ---------------------------------------------------------------------------
def etapa2_diagnostico():
    cob, resfin, nombres = [], [], []
    rx = re.compile(CONFIG["cultivo_regex"])
    for f in _partes():
        df = pd.read_parquet(f)
        g = df.groupby("ANIO")
        cob.append(pd.concat([g.size().rename("filas"), g.count()], axis=1))
        resfin.append(df.groupby(["ANIO", "RESFIN"], dropna=False).size())
        nom = df["P204_NOM"].dropna().astype(str).str.upper().str.strip()
        nombres.append(nom[nom.str.contains(rx)].value_counts())
    cob = pd.concat(cob).groupby(level=0).sum()
    pct = (100 * cob.drop(columns="filas").div(cob["filas"], axis=0)).round(1)
    pct.insert(0, "filas", cob["filas"])
    resfin = pd.concat(resfin).groupby(level=[0, 1]).sum().unstack(fill_value=0)
    nombres = pd.concat(nombres).groupby(level=0).sum().sort_values(ascending=False)
    with pd.ExcelWriter("diagnostico_ENA.xlsx") as xw:
        pct.to_excel(xw, sheet_name="cobertura_pct_por_anio")
        resfin.to_excel(xw, sheet_name="RESFIN_por_anio")
        nombres.rename("filas").to_frame().to_excel(xw, sheet_name="cultivos_detectados")
    with pd.option_context("display.width", 250, "display.max_columns", 50):
        print("[Etapa 2] filas por año:\n", pct["filas"].to_string())
        print("\n[Etapa 2] cultivos que entran en el filtro:\n", nombres.head(20).to_string())
    print("\n[Etapa 2] -> diagnostico_ENA.xlsx (revisa columnas con 0% en algún año)")


# ---------------------------------------------------------------------------
# ETAPA 3 (VENCERÁS): series por año y por departamento
# ---------------------------------------------------------------------------
def _peso(df):
    """FACTOR; en 2023-2024 viene vacío -> FACTOR_PRODUCTOR -> FACTOR_SUPERFICIE."""
    return _num(df["FACTOR"]).fillna(_num(df["FACTOR_PRODUCTOR"])).fillna(_num(df["FACTOR_SUPERFICIE"]))


def _parte_decimal(dec, divisor):
    d = _num(dec).fillna(0).abs()
    if divisor == "digitos":                       # 5 -> .5 ; 25 -> .25 ; 125 -> .125
        nd = np.where(d > 0, np.floor(np.log10(d.where(d > 0, 1))) + 1, 0)
        return d / (10.0 ** nd)
    return d / divisor


def _cantidad(ent, dec):
    return _num(ent) + _num(dec).fillna(0) / 1000      # decimal en milésimas


FACTOR_SUP = {"tabla": None, "nacional": None}


def _clase_cantidad(q):
    """Tramos de la cantidad declarada: los grandes casi siempre son m2."""
    return np.select([q < 1, q < 2, q < 5, q < 10, q < 30, q < 100],
                     ["q<1", "q1-2", "q2-5", "q5-10", "q10-30", "q30-100"], "q>=100")


def _cantidad_sup(d):
    return _num(d["P217_SUP_1"]).fillna(0) + _num(d["P217_SUP_2"]).fillna(0) / 1000


def _calibrar_superficie():
    """P217_SUP_1 + P217_SUP_2/1000 es la cantidad en la unidad que declaró el productor
    (m2, ha, yugada, topo...). La unidad no viene en la base, así que el factor a hectáreas
    se aprende en los años con P217_SUP_HA: Σ ha / Σ cantidad por (departamento, clase)."""
    if FACTOR_SUP["tabla"] is not None:
        return FACTOR_SUP
    rx = re.compile(CONFIG["cultivo_regex"])
    acum = []
    for f in _partes():                       # solo filas del cultivo y ponderadas
        d = pd.read_parquet(f, columns=["ANIO", "CCDD", "P204_NOM", "P217_SUP_HA", "P217_SUP_1",
                                        "P217_SUP_2", "FACTOR", "FACTOR_PRODUCTOR",
                                        "FACTOR_SUPERFICIE"])
        d = d[_num(d["P217_SUP_HA"]).notna() & _num(d["P217_SUP_1"]).notna() &
              d["P204_NOM"].astype(str).str.upper().str.strip().str.contains(rx)]
        q = _cantidad_sup(d)
        w = _peso(d)
        d = pd.DataFrame({"ANIO": d["ANIO"], "CCDD": d["CCDD"], "clase": _clase_cantidad(q),
                          "ha": _num(d["P217_SUP_HA"]) * w, "q": q * w})
        d = d[(q > 0) & w.notna()]
        acum.append(d.groupby(["ANIO", "CCDD", "clase"])[["ha", "q"]].sum())
    ta = pd.concat(acum).groupby(level=[0, 1, 2]).sum()
    t = ta.groupby(level=[1, 2]).sum()
    nac = t.groupby(level=1).sum()
    # validación: dejando fuera cada año, ¿cuánto se acerca la superficie imputada a la real?
    print("[info] validación de la imputación (superficie imputada / real, dejando fuera cada año):")
    for a in ta.index.get_level_values(0).unique():
        tr = ta.drop(index=a, level=0).groupby(level=[1, 2]).sum()
        fac = (tr["ha"] / tr["q"])
        fn = tr.groupby(level=1).sum(); fn = fn["ha"] / fn["q"]
        te = ta.xs(a, level=0)
        f_te = [fac.get(i, fn.get(i[1], np.nan)) for i in te.index]
        print(f"       {int(a)}: {np.nansum(te['q'].values * np.array(f_te)) / te['ha'].sum():.2f}")
    FACTOR_SUP["tabla"] = (t["ha"] / t["q"]).to_dict()
    FACTOR_SUP["nacional"] = (nac["ha"] / nac["q"]).to_dict()
    print("[info] factor cantidad -> ha aprendido (nacional):",
          {k: round(v, 5) for k, v in FACTOR_SUP["nacional"].items()})
    return FACTOR_SUP


def _superficie_imputada(c):
    fs = _calibrar_superficie()
    q = _cantidad_sup(c)
    clase = pd.Series(_clase_cantidad(q), index=c.index)
    fac = [fs["tabla"].get((dd, cl), fs["nacional"].get(cl, np.nan))
           for dd, cl in zip(c["CCDD"], clase)]
    sup = q * np.array(fac, dtype=float)
    return sup.where(_num(c["P217_SUP_1"]).notna() & (q > 0))


def _filas_cultivo(df):
    rx = re.compile(CONFIG["cultivo_regex"])
    nom = df["P204_NOM"].astype(str).str.upper().str.strip()
    c = df[nom.str.contains(rx) & df["RESFIN"].isin(CONFIG["resfin_validos"])].copy()
    c["w"] = _peso(c)
    # superficie cosechada (ha): directa o entero + decimal
    sup_alt = _superficie_imputada(c) if len(c) else pd.Series(dtype=float)
    c["sup_ha"] = _num(c["P217_SUP_HA"]).fillna(sup_alt)
    c["fuente_sup"] = np.where(_num(c["P217_SUP_HA"]).notna(), "P217_SUP_ha",
                               np.where(sup_alt.notna(), "P217_SUP_1+2 imputada", "sin dato"))
    # producción (kg) = cantidad x kg por unidad, con la primera fuente disponible
    fuentes = [
        ("P219", _cantidad(c["P219_CANT_1"], c["P219_CANT_2"]) * _num(c["P219_EQUIV_KG"])),
        ("P224", _cantidad(c["P224_CANT_1"], c["P224_CANT_2"]) * _num(c["P224_EQUIV_KG"])),
        ("P229D", _cantidad(c["P229D_CANT_ENT"], c["P229D_CANT_DEC"])
         * _num(c["P229D_EQUIV"]).fillna(_num(c["P229_EQUIV"]))),
    ]
    c["kg"], c["fuente_prod"] = np.nan, "sin dato"
    for nombre, valor in fuentes:
        usar = c["kg"].isna() & valor.notna()
        c.loc[usar, "kg"] = valor[usar]
        c.loc[usar, "fuente_prod"] = nombre
    rend = c["kg"] / c["sup_ha"]
    c["valida"] = (c["w"].notna() & (c["sup_ha"] > 0) &
                   rend.between(CONFIG["rend_min_kg_ha"], CONFIG["rend_max_kg_ha"]))
    c["riego"] = np.where(_num(c["P212"]).isna(), np.nan, (_num(c["P212"]) != 1).astype(float))
    c["sem_cert"] = np.where(_num(c["P214"]).isna(), np.nan, (_num(c["P214"]) == 1).astype(float))
    c["precio_kg"] = _num(c["P220_1_PRE_KG"])
    return c


def _sumas_cultivo(c, claves):
    c = c[c["valida"]]
    ws = c["w"] * c["sup_ha"]
    out = pd.DataFrame({k: c[k] for k in claves})
    out["n_registros_cultivo"] = 1
    out["kg_tot"] = c["kg"] * c["w"]
    out["ha_tot"] = ws
    out["riego_ha"] = (c["riego"] * ws).fillna(0)
    out["riego_den"] = ws.where(c["riego"].notna(), 0)
    out["semcert_ha"] = (c["sem_cert"] * ws).fillna(0)
    out["semcert_den"] = ws.where(c["sem_cert"].notna(), 0)
    pm = c["precio_kg"].between(0.01, 100)          # descarta precios absurdos
    out["precio_num"] = (c["precio_kg"] * c["w"]).where(pm, 0)
    out["precio_den"] = c["w"].where(pm, 0)
    return out.groupby(claves, dropna=False).sum().reset_index()


def _productores_bloque(df):
    """Una fila por productor dentro del bloque (máximo de cada indicador)."""
    d = df[df["RESFIN"].isin(CONFIG["resfin_validos"])].copy()
    d["CONGLO"] = d["CONGLOMERADO"].fillna(d["CONGLOME"]).fillna(d["NSEGM"])
    idp = d["ID_PROD"].astype(str).str.strip()
    d["SEL"] = d["NSELUA"].fillna(idp.where(~idp.isin(["", "nan", "None"])))
    rx = re.compile(CONFIG["cultivo_regex"])
    d["tiene_cultivo"] = d["P204_NOM"].astype(str).str.upper().str.strip().str.contains(rx).astype(float)
    si = lambda v: np.where(_num(d[v]).isna(), np.nan, (_num(d[v]) == 1).astype(float))
    d["fert"], d["abono"], d["asist"], d["capac"] = si("P238"), si("P236"), si("P704"), si("P701")
    d["asoc"], d["seguro"] = si("P801"), si("P905")
    p901, p902 = _num(d["P901"]), _num(d["P902"])
    d["credito"] = np.where(p901.isna(), np.nan, ((p901 == 1) & (p902 == 1)).astype(float))
    p224a = _num(d["P224A"])
    d["perd_helada"] = np.where(p224a.isna() & _num(d["P224E_4"]).isna(), np.nan,
                                (_num(d["P224E_4"]) == 1).astype(float))
    d["perd_sequia"] = np.where(p224a.isna() & _num(d["P224E_7"]).isna(), np.nan,
                                (_num(d["P224E_7"]) == 1).astype(float))
    d["w"] = _peso(d)
    claves = CLAVE_PRODUCTOR
    ind = ["w", "tiene_cultivo", "fert", "abono", "asist", "capac", "asoc", "seguro",
           "credito", "perd_helada", "perd_sequia"]
    return d.groupby(claves, dropna=False)[ind].max().reset_index()


CLAVE_PRODUCTOR = ["ANIO", "CCDD", "CCPP", "CCDI", "CONGLO", "SEL", "UA"]

IND_PROD = ["fert", "abono", "asist", "capac", "asoc", "seguro", "credito",
            "perd_helada", "perd_sequia"]


def _resumen_productores(p, claves):
    p = p[p["tiene_cultivo"] == 1].copy()
    # sin registro de pérdida total = no tuvo pérdida (en 2025 el módulo 1896 solo trae a quienes perdieron)
    p[["perd_helada", "perd_sequia"]] = p[["perd_helada", "perd_sequia"]].fillna(0)
    filas = []
    for k, g in p.groupby(claves):
        k = k if isinstance(k, tuple) else (k,)
        fila = dict(zip(claves, k))
        fila["n_productores_cultivo"] = len(g)
        fila["productores_expandidos"] = g["w"].sum()
        for v in IND_PROD:
            fila[f"pct_{v}"] = 100 * _wmean(g[v], g["w"])
        filas.append(fila)
    return pd.DataFrame(filas)


def _finalizar_cultivo(s):
    r = s[[c for c in s.columns if c not in
           ("kg_tot", "ha_tot", "riego_ha", "riego_den", "semcert_ha", "semcert_den",
            "precio_num", "precio_den")]].copy()
    r["produccion_t"] = s["kg_tot"] / 1000
    r["superficie_cosechada_ha"] = s["ha_tot"]
    r["rendimiento_kg_ha"] = s["kg_tot"] / s["ha_tot"]
    r["pct_area_con_riego"] = 100 * s["riego_ha"] / s["riego_den"].replace(0, np.nan)
    r["pct_area_semilla_cert"] = 100 * s["semcert_ha"] / s["semcert_den"].replace(0, np.nan)
    r["precio_venta_kg"] = s["precio_num"] / s["precio_den"].replace(0, np.nan)
    return r


def etapa3_agregar():
    sc_nac, sc_dep, prods, fuentes = [], [], [], []
    primero = True
    for f in _partes():                                   # cada bloque por separado
        df = pd.read_parquet(f)
        c = _filas_cultivo(df)
        sc_nac.append(_sumas_cultivo(c, ["ANIO"]))
        sc_dep.append(_sumas_cultivo(c, ["ANIO", "CCDD"]))
        prods.append(_productores_bloque(df))
        fuentes.append(c.groupby(["ANIO", "fuente_prod", "fuente_sup", "valida"]).size())
        cols = ["ANIO", "CCDD", "NOMBREDD", "REGION", "w", "P204_NOM", "sup_ha", "kg",
                "fuente_prod", "fuente_sup", "valida", "riego", "sem_cert", "precio_kg"]
        c[cols].rename(columns={"w": "factor", "kg": "produccion_kg"}).to_csv(
            "ENA_cultivo_filas.csv", mode="w" if primero else "a", header=primero,
            index=False, encoding="utf-8-sig")
        primero = False
    # combinar (vencer): sumas parciales y productores partidos entre bloques
    nac = _finalizar_cultivo(pd.concat(sc_nac).groupby("ANIO").sum().reset_index())
    dep = _finalizar_cultivo(pd.concat(sc_dep).groupby(["ANIO", "CCDD"]).sum().reset_index())
    p = pd.concat(prods).groupby(CLAVE_PRODUCTOR, dropna=False).max().reset_index()
    p.to_csv("ENA_productores.csv", index=False, encoding="utf-8-sig")
    nac = nac.merge(_resumen_productores(p, ["ANIO"]), on="ANIO", how="left")
    dep = dep.merge(_resumen_productores(p, ["ANIO", "CCDD"]), on=["ANIO", "CCDD"], how="left")
    dep.insert(2, "DEPARTAMENTO", dep["CCDD"].map(DEPARTAMENTOS))
    for t in (nac, dep):
        t["ANIO"] = t["ANIO"].astype(int)
    fuentes = pd.concat(fuentes).groupby(level=[0, 1, 2, 3]).sum().rename("filas").reset_index()
    puno = dep[dep["CCDD"] == "21"]
    nota = pd.DataFrame({"campo": [
        "Unidad", "Filtro de cultivo", "Ponderador", "Producción (kg)", "Rendimiento",
        "pct_area_con_riego", "pct_area_semilla_cert", "pct_* de productores",
        "pct_credito", "Departamento"], "definición": [
        "Fila de cultivo cosechado (P204) para producción/superficie; productor para pct_*",
        f"P204_NOM coincide con {CONFIG['cultivo_regex']} y RESFIN en {CONFIG['resfin_validos']}",
        "FACTOR (factor de expansión)",
        "Cantidad x kg por unidad: P219; si falta, P224; si falta, P229D (ver hoja fuentes)",
        "Σ(FACTOR·kg)/Σ(FACTOR·ha). ha = P217_SUP_ha; en 2015 y 2018 (sin P217_SUP_ha) = (P217_SUP_1 + P217_SUP_2/1000) × factor a ha aprendido por departamento y tamaño en los demás años. FACTOR o FACTOR_PRODUCTOR (2023-24)",
        "% de la superficie cosechada cuya agua no es lluvia (P212 ≠ 1)",
        "% de la superficie cosechada con semilla certificada (P214 = 1)",
        "% ponderado de productores del cultivo con respuesta Sí (P238, P236, P704, P701, P801, P905)",
        "Solicitó (P901=1) y obtuvo (P902=1); base: respondieron P901",
        "Dos primeros dígitos de CCDD (Puno = 21)"]})
    with pd.ExcelWriter(SALIDA_SERIES) as xw:
        nac.to_excel(xw, sheet_name="serie_nacional", index=False)
        puno.to_excel(xw, sheet_name="serie_puno", index=False)
        dep.to_excel(xw, sheet_name="panel_departamental", index=False)
        nota.to_excel(xw, sheet_name="nota_metodologica", index=False)
        fuentes.to_excel(xw, sheet_name="fuentes_por_anio", index=False)
    with pd.option_context("display.width", 250, "display.max_columns", 30):
        print(nac[["ANIO", "n_registros_cultivo", "produccion_t", "superficie_cosechada_ha",
                   "rendimiento_kg_ha", "pct_area_con_riego", "pct_fert", "pct_credito"]]
              .round(1).to_string(index=False))
    tot = fuentes.groupby("ANIO")["filas"].sum()
    ok = fuentes[fuentes["valida"]].groupby("ANIO")["filas"].sum()
    print("\n[Etapa 3] % de filas de papa utilizables por año:")
    print((100 * ok.reindex(tot.index, fill_value=0) / tot).round(1).to_string())
    print(f"[Etapa 3] -> {SALIDA_SERIES}, ENA_cultivo_filas.csv, ENA_productores.csv")


def etapa_muestra(salida="muestra_superficie.csv", n_por_anio=1500):
    """Muestra pequeña de filas de papa con las columnas crudas de superficie y producción."""
    cols = ["ANIO", "CCDD", "P204_NOM", "P217_SUP_HA", "P217_SUP_1", "P217_SUP_2",
            "P219_CANT_1", "P219_CANT_2", "P219_EQUIV_KG", "FACTOR"]
    rx = re.compile(CONFIG["cultivo_regex"])
    partes = []
    for f in _partes():
        d = pd.read_parquet(f, columns=cols)
        d = d[d["P204_NOM"].astype(str).str.upper().str.strip().str.contains(rx)]
        partes.append(d)
    d = pd.concat(partes)
    d = d.sample(frac=1, random_state=1).groupby("ANIO").head(n_por_anio).sort_values("ANIO")
    d.to_csv(salida, index=False, encoding="utf-8-sig")
    print(f"-> {salida} ({len(d):,} filas)")


# ---------------------------------------------------------------------------
# opcionales: microdata reducida completa
# ---------------------------------------------------------------------------
def etapa_csv_completo(salida="ENA_reducida.csv"):
    for i, f in enumerate(_partes()):
        pd.read_parquet(f).to_csv(salida, mode="w" if i == 0 else "a", header=i == 0,
                                  index=False, encoding="utf-8-sig")
    print(f"-> {salida}")


def etapa_xlsx_por_anio(salida="ENA_reducida.xlsx"):
    df = pd.concat(pd.read_parquet(f) for f in _partes())
    with pd.ExcelWriter(salida, engine="xlsxwriter",
                        engine_kwargs={"options": {"constant_memory": True}}) as xw:
        for a, sub in df.groupby("ANIO"):
            for k in range(0, len(sub), LIMITE_XLSX):
                hoja = f"{int(a)}" + (f"_{k // LIMITE_XLSX + 1}" if len(sub) > LIMITE_XLSX else "")
                sub.iloc[k:k + LIMITE_XLSX].to_excel(xw, sheet_name=hoja, index=False)
    print(f"-> {salida}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(0)
    paso, args = sys.argv[1], sys.argv[2:]
    acciones = {
        "diccionario": lambda: etapa0_diccionario(args[0]),
        "buscar": lambda: etapa_buscar(args),
        "extraer": lambda: etapa1_extraer(args[0], int(args[1]) if len(args) > 1 else None),
        "diagnostico": etapa2_diagnostico,
        "agregar": etapa3_agregar,
        "muestra": etapa_muestra,
        "csv_completo": etapa_csv_completo,
        "xlsx_por_anio": etapa_xlsx_por_anio,
    }
    acciones.get(paso, lambda: print(__doc__))()
