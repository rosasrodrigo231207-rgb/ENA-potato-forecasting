# Genera figuras, tablas y macros del artículo a partir de los pronósticos.
# Uso: python make_paper_assets.py resultados/pronosticos_todos_los_modelos.csv   (IDIOMA=es para la versión en español)
import sys
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import friedmanchisquare, wilcoxon
import ena_forecast as E

warnings.filterwarnings("ignore")
OUT = "../articulo"
import os
ES = os.environ.get("IDIOMA") == "es"
SUF = "_es" if ES else ""
T = (lambda en, es: es if ES else en)
ETQ = {"Naive": T("Naive", "Ingenuo"), "ARIMA": "ARIMA", "ETS": "ETS", "Chronos-2": "Chronos-2"}
plt.rcParams.update({"font.family": "serif", "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
                     "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8, "legend.fontsize": 6.5,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "lines.linewidth": 1.1,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300})
COL = {"Naive": "#7f7f7f", "ARIMA": "#2e75b6", "ETS": "#548235", "Chronos-2": "#c55a11"}
NAC = "Peru (national)"

# --------------------------------------------------------------------------- datos
# argumento: CSV de pronósticos exportado por el notebook (incluye Chronos-2)
pron = pd.read_csv(sys.argv[-1])
pron["serie"] = pron["serie"].replace({"Perú (nacional)": NAC})
MOD = [m for m in E.MODELOS if m in pron["modelo"].unique()]
ancho = E.series_completas(E.leer_series("../datos/series_ENA_papa.xlsx"))
met = E.metricas(pron, ancho)

# --------------------------------------------------------------------------- Fig. 1
fig, axes = plt.subplots(1, 2, figsize=(3.5, 1.55))
for ax, n, t in zip(axes, [NAC, "Puno"], [T("(a) Peru (national)", "(a) Perú (nacional)"), "(b) Puno"]):
    s, imp = E.interpolar_2020(ancho[n])
    ax.plot(s.index, s.values / 1000, "-o", color="#1f3864", ms=2.6)
    ax.plot(s.index[imp], s.values[imp] / 1000, "o", mfc="white", mec="#c00000", ms=4.5, mew=1.2)
    ax.set_title(t); ax.set_xticks([2015, 2018, 2021, 2024]); ax.grid(alpha=.25, lw=.5)
axes[0].set_ylabel(T("Yield (t/ha)", "Rendimiento (t/ha)"))
axes[1].annotate(T("2023 frost", "helada 2023"), xy=(2023, ancho.loc[2023, "Puno"] / 1000), xytext=(2016.2, 3.9),
                 fontsize=6, arrowprops=dict(arrowstyle="->", lw=.6))
axes[0].annotate(T("2020\ninterpolated", "2020\ninterpolado"), xy=(2020, E.interpolar_2020(ancho[NAC])[0][2020] / 1000),
                 xytext=(2015.3, 12.1), fontsize=6, color="#c00000",
                 arrowprops=dict(arrowstyle="->", lw=.6, color="#c00000"))
fig.tight_layout(pad=.3, w_pad=.8)
fig.savefig(f"{OUT}/fig1_series{SUF}.pdf")

# --------------------------------------------------------------------------- Fig. 3 (holdout)
fig, axes = plt.subplots(1, 2, figsize=(3.5, 1.75))
for ax, n, t in zip(axes, [NAC, "Puno"], [T("(a) Peru (national)", "(a) Perú (nacional)"), "(b) Puno"]):
    s, _ = E.interpolar_2020(ancho[n])
    ax.axvspan(2021.5, 2025.5, color="#fff2cc", zorder=0)
    ax.plot(s.index, s.values / 1000, "-o", color="black", ms=2.4, label=T("Observed", "Observado"))
    d = pron[(pron.serie == n) & (pron.esquema == "holdout")]
    for m in MOD:
        g = d[d.modelo == m]
        x = np.r_[2021, g.anio]; y = np.r_[s[2021], g.pred] / 1000
        ax.plot(x, y, "--", color=COL[m], label=ETQ[m], lw=1)
        ax.fill_between(g.anio, g.li80 / 1000, g.ls80 / 1000, color=COL[m], alpha=.10, lw=0)
    ax.set_title(t); ax.set_xticks([2015, 2018, 2021, 2024]); ax.grid(alpha=.25, lw=.5)
axes[0].set_ylabel(T("Yield (t/ha)", "Rendimiento (t/ha)"))
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=len(l), frameon=False, bbox_to_anchor=(.5, -.02))
fig.tight_layout(pad=.3, w_pad=.8, rect=(0, .1, 1, 1))
fig.savefig(f"{OUT}/fig3_holdout{SUF}.pdf")

# --------------------------------------------------------------------------- Fig. 4 (futuro)
fig, axes = plt.subplots(1, 2, figsize=(3.5, 1.75))
for ax, n, t in zip(axes, [NAC, "Puno"], [T("(a) Peru (national)", "(a) Perú (nacional)"), "(b) Puno"]):
    s, _ = E.interpolar_2020(ancho[n])
    ax.plot(s.index, s.values / 1000, "-o", color="black", ms=2.4, label=T("Observed", "Observado"))
    d = pron[(pron.serie == n) & (pron.esquema == "future")]
    for m in MOD:
        g = d[d.modelo == m]
        ax.plot(np.r_[2025, g.anio], np.r_[s[2025], g.pred] / 1000, "--o", ms=2, color=COL[m], label=ETQ[m], lw=1)
        ax.fill_between(g.anio, g.li80 / 1000, g.ls80 / 1000, color=COL[m], alpha=.10, lw=0)
    ax.set_title(t); ax.set_xticks([2015, 2019, 2023, 2027]); ax.grid(alpha=.25, lw=.5)
axes[0].set_ylabel(T("Yield (t/ha)", "Rendimiento (t/ha)"))
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=len(l), frameon=False, bbox_to_anchor=(.5, -.02))
fig.tight_layout(pad=.3, w_pad=.8, rect=(0, .1, 1, 1))
fig.savefig(f"{OUT}/fig4_future{SUF}.pdf")

# --------------------------------------------------------------------------- Tabla II (nacional y Puno)
def _loc(t):
    return t.replace(",", "\\,").replace(".", "{,}") if ES else t
def f0(x): return _loc(f"{x:,.0f}")
def f1(x): return _loc(f"{x:.1f}")
def f2(x): return _loc(f"{x:.2f}")
filas = []
for m in MOD:
    r = [m]
    for esq in ["holdout", "rolling"]:
        for n in [NAC, "Puno"]:
            x = met[(met.esquema == esq) & (met.serie == n) & (met.modelo == m)].iloc[0]
            r += [f0(x.MAE), f1(x.MAPE)]
    filas.append(r)
# negrita al mejor MAPE de cada columna
arr = np.array(filas, dtype=object)
for j in range(2, arr.shape[1], 2):
    v = [float(str(a).replace("{,}", ".").replace("\\,", "")) for a in arr[:, j]]
    for i in np.where(np.isclose(v, min(v)))[0]:
        arr[i, j] = r"\textbf{" + arr[i, j] + "}"
with open(f"{OUT}/tab_accuracy{SUF}.tex", "w") as fh:
    for r in arr:
        r = list(r); r[0] = ETQ[r[0]]
        fh.write(" & ".join(r) + r" \\" + "\n")

# --------------------------------------------------------------------------- Tabla III (20 series)
res = {}
piv = lambda esq, v: met[met.esquema == esq].pivot(index="serie", columns="modelo", values=v)[MOD]
with open(f"{OUT}/tab_panel{SUF}.tex", "w") as fh:
    filas3 = []
    for m in MOD:
        r = [ETQ[m]]
        for esq in ["holdout", "rolling"]:
            t, ma, ms, c = piv(esq, "MAPE"), piv(esq, "MASE"), piv(esq, "MSIS"), piv(esq, "Cobertura80")
            rk = t.rank(axis=1).mean()
            wins = t.idxmin(axis=1).value_counts().reindex(MOD, fill_value=0)
            r += [f1(t[m].mean()), f2(ma[m].mean()), f2(ms[m].mean()), f2(rk[m]), str(wins[m]), f2(c[m].mean())]
            res[esq] = (t, c, rk, wins, ma, ms)
        filas3.append(r)
    arr = np.array(filas3, dtype=object)
    for j in [1, 2, 3, 4, 7, 8, 9, 10]:                       # menor = mejor -> negrita
        v = [float(str(a).replace("{,}", ".").replace("\\,", "")) for a in arr[:, j]]
        for i in np.where(np.isclose(v, min(v)))[0]:
            arr[i, j] = r"\textbf{" + arr[i, j] + "}"
    num = lambda a: float(str(a).replace("{,}", ".").replace("\\,", "").replace(r"\textbf{", "").rstrip("}"))
    for j in [5, 11]:                                  # series ganadas: mayor = mejor
        v = [num(a) for a in arr[:, j]]
        for i2 in np.where(np.isclose(v, max(v)))[0]:
            arr[i2, j] = r"\textbf{" + arr[i2, j] + "}"
    for j in [6, 12]:                                  # cobertura: más cerca de 0,80
        v = [abs(num(a) - E.NIVEL) for a in arr[:, j]]
        for i2 in np.where(np.isclose(v, min(v)))[0]:
            arr[i2, j] = r"\textbf{" + arr[i2, j] + "}"
    for r in arr:
        fh.write(" & ".join(r) + r" \\" + "\n")

# --------------------------------------------------------------------------- macros con cifras
mac = {}
for esq in ["holdout", "rolling"]:
    t, c, rk, wins, ma, ms = res[esq]
    mac[f"friedman{esq}"] = f2(friedmanchisquare(*[t[k] for k in MOD]).pvalue)
    mac[f"friedmanmase{esq}"] = f2(friedmanchisquare(*[ma[k] for k in MOD]).pvalue)
    mac[f"friedmanmsis{esq}"] = f2(friedmanchisquare(*[ms[k] for k in MOD]).pvalue)
    mac[f"masemin{esq}"] = f2(ma.mean().min()); mac[f"masemax{esq}"] = f2(ma.mean().max())
nac = ancho[NAC]; pun = ancho["Puno"]
mac.update({
    "nacmean": f0(nac.mean()), "nacmin": f0(nac.min()), "nacmax": f0(nac.max()),
    "punmean": f0(pun.mean()), "punmin": f0(pun.min()), "punmax": f0(pun.max()),
    "nacinterp": f0(E.interpolar_2020(nac)[0][2020]), "puninterp": f0(E.interpolar_2020(pun)[0][2020]),
    "nacratio": f1(nac.mean() / pun.mean()),
})
# órdenes ARIMA elegidos
ordenes = []
for n in ancho.columns:
    s, _ = E.interpolar_2020(ancho[n])
    ordenes.append(E.modelo_arima(s.loc[:E.ORIGEN_HOLDOUT].values, 4, True)[3])
mac["arimawhite"] = str(sum(o == (0, 0, 0) for o in ordenes))
from statsmodels.tsa.exponential_smoothing.ets import ETSModel
alfas = []
for n in ancho.columns:
    s, _ = E.interpolar_2020(ancho[n])
    alfas.append(ETSModel(pd.Series(s.loc[:E.ORIGEN_HOLDOUT].values), error="add").fit(disp=False).params[0])
alfas = np.array(alfas)
mac["etszero"] = str(int((alfas < 0.05).sum()))
mac["etsone"] = str(int((alfas > 0.95).sum()))
print("alfas", dict(zip(ancho.columns, alfas.round(3))))
fut = pron[pron.esquema == "future"]
for m in MOD:
    k = m.replace("-2", "two").replace("Naive", "naive").replace("ARIMA", "arima").replace("ETS", "ets").replace("Chronos", "chronos")
    for n, kk in [(NAC, "nac"), ("Puno", "pun")]:
        g = fut[(fut.serie == n) & (fut.modelo == m)].set_index("anio")
        for a in [2026, 2028]:
            mac[f"{kk}{k}{'a' if a == 2026 else 'c'}"] = f0(g.loc[a, "pred"])
            mac[f"{kk}{k}{'a' if a == 2026 else 'c'}lo"] = f0(g.loc[a, "li80"])
            mac[f"{kk}{k}{'a' if a == 2026 else 'c'}hi"] = f0(g.loc[a, "ls80"])
with open(f"{OUT}/numbers{SUF}.tex", "w") as fh:
    for k, v in mac.items():
        fh.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")

# reporte en consola para redactar
pd.set_option("display.width", 200)
print(met[met.serie.isin([NAC, "Puno"])].round(2).to_string(index=False))
for esq in ["holdout", "rolling"]:
    t, c, rk, wins, ma, ms = res[esq]
    print("MASE", ma.mean().round(2).to_dict(), "MSIS", ms.mean().round(2).to_dict())
    print(esq, "\nmean", t.mean().round(2).to_dict(), "\nmedian", t.median().round(2).to_dict(),
          "\nrank", rk.round(2).to_dict(), "\nwins", wins.to_dict(), "\ncov", c.mean().round(2).to_dict(),
          "\nfriedman", mac[f"friedman{esq}"])
    if "Chronos-2" in MOD:
        for m in MOD:
            if m != "Chronos-2":
                print("  Wilcoxon Chronos vs", m, round(wilcoxon(t["Chronos-2"], t[m]).pvalue, 3))
print({k: v for k, v in mac.items()})
print("ARIMA orders:", ordenes)
