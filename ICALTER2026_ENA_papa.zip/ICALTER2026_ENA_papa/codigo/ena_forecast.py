# -*- coding: utf-8 -*-
"""
ena_forecast.py
Pronóstico del rendimiento de papa (ENA 2015–2025): modelos clásicos vs. Chronos-2.
Rosas Tuni, R. C. et al. - FINESI, Universidad Nacional del Altiplano (Puno, Perú)

Funciones compartidas por el notebook de Colab y por los scripts del artículo.
"""
import warnings
import numpy as np
import pandas as pd

ANIOS = list(range(2015, 2026))          # 2015–2025 (2020 se interpola)
ANIO_FALTANTE = 2020                     # sin ENA por la COVID-19
ORIGEN_HOLDOUT = 2021                    # entrenamiento 2015–2021, prueba 2022–2025
ORIGENES_ROLLING = [2021, 2022, 2023, 2024]
HORIZONTE_FUTURO = 3                     # 2026–2028
NIVEL = 0.80                             # intervalos de predicción del 80 %
MODELOS = ["Naive", "ARIMA", "ETS", "Chronos-2"]


# ---------------------------------------------------------------------------
# 1. Datos
# ---------------------------------------------------------------------------
def leer_series(xlsx):
    """Devuelve un DataFrame ancho: índice = año (2015–2025, sin 2020), columnas = series."""
    nac = pd.read_excel(xlsx, sheet_name="serie_nacional")
    dep = pd.read_excel(xlsx, sheet_name="panel_departamental", dtype={"CCDD": str})
    s = dep.pivot(index="ANIO", columns="DEPARTAMENTO", values="rendimiento_kg_ha")
    s.insert(0, "Peru (national)", nac.set_index("ANIO")["rendimiento_kg_ha"])
    return s.sort_index()


def series_completas(ancho):
    """Solo las series con los 10 años observados (descarta Loreto y San Martín)."""
    return ancho.loc[:, ancho.notna().all()]


def interpolar_2020(serie):
    """Inserta 2020 y lo estima por interpolación lineal entre 2019 y 2021."""
    s = serie.reindex(ANIOS).astype(float)
    imput = s.isna()
    s = s.interpolate(method="linear")
    return s, imput


# ---------------------------------------------------------------------------
# 2. Modelos (cada uno recibe la historia y devuelve media, li y ls del 80 %)
# ---------------------------------------------------------------------------
def _z():
    from scipy.stats import norm
    return norm.ppf(0.5 + NIVEL / 2)


def modelo_naive(y, h):
    """Ingenuo: el próximo año = último valor observado. Intervalo de un paseo aleatorio."""
    y = np.asarray(y, float)
    sd = np.std(np.diff(y), ddof=1)
    k = np.arange(1, h + 1)
    m = np.repeat(y[-1], h)
    return m, m - _z() * sd * np.sqrt(k), m + _z() * sd * np.sqrt(k)


def elegir_d(y):
    """d por la prueba KPSS al 5 % (como en el procedimiento de Hyndman–Khandakar)."""
    from statsmodels.tsa.stattools import kpss
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        p = kpss(y, regression="c", nlags="auto")[1]
    return 1 if p < 0.05 else 0


def modelo_arima(y, h, devolver_orden=False):
    """ARIMA(p,d,q): d por KPSS; p,q en {0,1} elegidos por AICc (búsqueda restringida por la serie corta)."""
    from statsmodels.tsa.arima.model import ARIMA
    y = np.asarray(y, float)
    mejor = None
    for d in (elegir_d(y),):
        for p in (0, 1):
            for q in (0, 1):
                tendencia = "c" if d == 0 else "n"
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        r = ARIMA(y, order=(p, d, q), trend=tendencia).fit()
                    if not np.isfinite(r.aicc):
                        continue
                    if mejor is None or r.aicc < mejor[0]:
                        mejor = (r.aicc, (p, d, q), r)
                except Exception:
                    continue
    _, orden, r = mejor
    f = r.get_forecast(h)
    ci = f.conf_int(alpha=1 - NIVEL)
    salida = (f.predicted_mean, ci[:, 0], ci[:, 1])
    return (*salida, orden) if devolver_orden else salida


def modelo_ets(y, h):
    """Suavizamiento exponencial simple, ETS(A,N,N)."""
    from statsmodels.tsa.exponential_smoothing.ets import ETSModel
    y = pd.Series(np.asarray(y, float))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        r = ETSModel(y, error="add", trend=None, seasonal=None).fit(disp=False)
        f = r.get_prediction(start=len(y), end=len(y) + h - 1).summary_frame(alpha=1 - NIVEL)
    return f["mean"].values, f["pi_lower"].values, f["pi_upper"].values


_PIPE = {"obj": None}


def cargar_chronos(nombre="amazon/chronos-2", device="cpu"):
    """Carga Chronos-2 (gratuito, licencia Apache-2.0). Requiere: pip install chronos-forecasting"""
    if _PIPE["obj"] is None:
        from chronos import Chronos2Pipeline
        _PIPE["obj"] = Chronos2Pipeline.from_pretrained(nombre, device_map=device)
    return _PIPE["obj"]


def _a_numpy(t):
    if hasattr(t, "detach"):
        t = t.detach().float().cpu().numpy()
    return np.asarray(t, dtype=float)


def modelo_chronos(y, h):
    """Chronos-2 zero-shot: no se entrena; recibe la historia y devuelve los cuantiles 0.1, 0.5 y 0.9."""
    pipe = cargar_chronos()
    q, _ = pipe.predict_quantiles(
        [np.asarray(y, dtype=np.float32)],
        prediction_length=h,
        quantile_levels=[0.1, 0.5, 0.9],
    )
    q = _a_numpy(q[0]).reshape(-1, 3)[-h:]      # (h, 3): li, mediana, ls
    return q[:, 1], q[:, 0], q[:, 2]


FUNCIONES = {"Naive": modelo_naive, "ARIMA": modelo_arima, "ETS": modelo_ets,
             "Chronos-2": modelo_chronos}


# ---------------------------------------------------------------------------
# 3. Validación temporal y pronóstico futuro
# ---------------------------------------------------------------------------
def pronosticar_todo(ancho, modelos=MODELOS):
    """Holdout (origen 2021, h=1..4), ventana expansiva (h=1) y futuro 2026–2028.
    Devuelve una tabla larga con una fila por pronóstico."""
    filas = []
    for nombre in ancho.columns:
        s, _ = interpolar_2020(ancho[nombre])
        for mod in modelos:
            f = FUNCIONES[mod]
            # (a) holdout: entrena 2015–2021, pronostica 2022–2025
            tr = s.loc[:ORIGEN_HOLDOUT]
            te = s.loc[ORIGEN_HOLDOUT + 1:]
            m, lo, hi = f(tr.values, len(te))
            for k, a in enumerate(te.index):
                filas.append([nombre, "holdout", ORIGEN_HOLDOUT, a, k + 1, mod, te[a], m[k], lo[k], hi[k]])
            # (b) ventana expansiva: un paso adelante desde 2021, 2022, 2023 y 2024
            for o in ORIGENES_ROLLING:
                m, lo, hi = f(s.loc[:o].values, 1)
                filas.append([nombre, "rolling", o, o + 1, 1, mod, s[o + 1], m[0], lo[0], hi[0]])
            # (c) futuro: entrena 2015–2025, pronostica 2026–2028
            m, lo, hi = f(s.values, HORIZONTE_FUTURO)
            for k in range(HORIZONTE_FUTURO):
                filas.append([nombre, "future", 2025, 2026 + k, k + 1, mod, np.nan, m[k], lo[k], hi[k]])
    cols = ["serie", "esquema", "origen", "anio", "h", "modelo", "y_real", "pred", "li80", "ls80"]
    return pd.DataFrame(filas, columns=cols)


def metricas(pron, ancho=None):
    """MAE (kg/ha), MAPE (%), cobertura del intervalo del 80 %, y si se da `ancho`:
    MASE (error escalado por el error del método ingenuo en el entrenamiento) y
    MSIS (interval score de Winkler escalado igual, α = 0,20)."""
    d = pron[pron["esquema"] != "future"].copy()
    d["ae"] = (d["y_real"] - d["pred"]).abs()
    d["ape"] = 100 * d["ae"] / d["y_real"].abs()
    d["cub"] = ((d["y_real"] >= d["li80"]) & (d["y_real"] <= d["ls80"])).astype(float)
    agg = dict(MAE=("ae", "mean"), MAPE=("ape", "mean"), Cobertura80=("cub", "mean"))
    if ancho is not None:
        a = 1 - NIVEL
        hist = {n: interpolar_2020(ancho[n])[0] for n in ancho.columns}
        d["escala"] = [np.mean(np.abs(np.diff(hist[s].loc[:o].values))) for s, o in zip(d["serie"], d["origen"])]
        d["ase"] = d["ae"] / d["escala"]
        isc = ((d["ls80"] - d["li80"]) + (2 / a) * (d["li80"] - d["y_real"]).clip(lower=0)
               + (2 / a) * (d["y_real"] - d["ls80"]).clip(lower=0))
        d["sis"] = isc / d["escala"]
        agg.update(MASE=("ase", "mean"), MSIS=("sis", "mean"))
    agg["n"] = ("ae", "size")
    return d.groupby(["esquema", "serie", "modelo"]).agg(**agg).reset_index()
