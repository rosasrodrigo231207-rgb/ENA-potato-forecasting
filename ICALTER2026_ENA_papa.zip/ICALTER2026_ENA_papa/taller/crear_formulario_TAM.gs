/**
 * Crea automáticamente el cuestionario TAM en Google Forms.
 * Cómo usarlo:
 *   1. Entra a https://script.google.com  →  "Nuevo proyecto".
 *   2. Borra el contenido, pega este archivo completo y guarda.
 *   3. Elige la función crearFormularioTAM y pulsa "Ejecutar" (acepta los permisos).
 *   4. En "Registro de ejecución" aparecen el enlace para responder y el de edición.
 */
function crearFormularioTAM() {
  var form = FormApp.create('Evaluación del notebook de pronóstico ENA (TAM)');
  form.setDescription(
    'Taller: Pronóstico del rendimiento de papa con datos oficiales (ENA 2015–2025).\n' +
    'Este cuestionario es anónimo y voluntario. Tus respuestas solo se usarán con fines académicos ' +
    'para evaluar el recurso didáctico. Tiempo estimado: 3 minutos.');
  form.setCollectEmail(false);

  form.addMultipleChoiceItem()
      .setTitle('Consentimiento informado: ¿aceptas participar voluntariamente en esta evaluación?')
      .setChoiceValues(['Sí, acepto participar', 'No acepto'])
      .setRequired(true);

  form.addMultipleChoiceItem()
      .setTitle('Semestre que cursas')
      .setChoiceValues(['IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'Otro'])
      .setRequired(false);

  var bloques = [
    ['Utilidad percibida (PU)', [
      'PU1. El notebook me ayuda a entender cómo se valida un pronóstico.',
      'PU2. El notebook me ayuda a comparar modelos clásicos con un modelo de IA.',
      'PU3. Trabajar con datos oficiales de la ENA hace que el tema sea más relevante para mí.'
    ]],
    ['Facilidad de uso percibida (PEOU)', [
      'PEOU1. El notebook es fácil de ejecutar sin instalar programas.',
      'PEOU2. El panel interactivo es fácil de usar.',
      'PEOU3. Las explicaciones del notebook son claras.'
    ]],
    ['Intención de uso (BI)', [
      'BI1. Usaría el notebook para practicar fuera de clase.',
      'BI2. Volvería a usarlo con otras bases de datos oficiales.',
      'BI3. Recomendaría el notebook a otros estudiantes.'
    ]]
  ];

  bloques.forEach(function (b) {
    form.addSectionHeaderItem().setTitle(b[0])
        .setHelpText('1 = Totalmente en desacuerdo … 5 = Totalmente de acuerdo');
    b[1].forEach(function (texto) {
      form.addScaleItem()
          .setTitle(texto)
          .setBounds(1, 5)
          .setLabels('Totalmente en desacuerdo', 'Totalmente de acuerdo')
          .setRequired(true);
    });
  });

  form.addParagraphTextItem()
      .setTitle('Comentarios o sugerencias para mejorar el notebook (opcional)');

  Logger.log('Enlace para responder: ' + form.getPublishedUrl());
  Logger.log('Enlace de edición:     ' + form.getEditUrl());
}
