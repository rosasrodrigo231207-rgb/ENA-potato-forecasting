# -*- coding: utf-8 -*-
"""
Análisis del cuestionario TAM (exportado de Google Forms como CSV).
Uso:  python analisis_TAM.py respuestas.csv
Calcula, por constructo (PU, PEOU, BI): alfa de Cronbach, media, DE y % de acuerdo (4–5).
"""
import sys
import pandas as pd

CONSTRUCTOS = {"PU": ["PU1", "PU2", "PU3"],
               "PEOU": ["PEOU1", "PEOU2", "PEOU3"],
               "BI": ["BI1", "BI2", "BI3"]}


def alfa_cronbach(items):
    k = items.shape[1]
    var_items = items.var(axis=0, ddof=1).sum()
    var_total = items.sum(axis=1).var(ddof=1)
    return k / (k - 1) * (1 - var_items / var_total)


def main(ruta):
    df = pd.read_csv(ruta)
    # solo quienes aceptaron el consentimiento
    col_cons = [c for c in df.columns if c.lower().startswith("consentimiento")]
    if col_cons:
        df = df[df[col_cons[0]].astype(str).str.startswith("Sí")]
    # renombrar columnas "PU1. El notebook…" -> "PU1"
    df = df.rename(columns={c: c.split(".")[0].strip() for c in df.columns
                            if c.split(".")[0].strip() in sum(CONSTRUCTOS.values(), [])})
    print(f"Respuestas válidas: n = {len(df)}\n")
    filas = []
    for k, cols in CONSTRUCTOS.items():
        x = df[cols].apply(pd.to_numeric, errors="coerce").dropna()
        filas.append({"Constructo": k, "alfa": round(alfa_cronbach(x), 3),
                      "Media": round(x.values.mean(), 2), "DE": round(x.values.std(ddof=1), 2),
                      "% acuerdo (4-5)": round(100 * (x.values >= 4).mean(), 1)})
    print(pd.DataFrame(filas).to_string(index=False))
    print("\nPor ítem:")
    it = df[sum(CONSTRUCTOS.values(), [])].apply(pd.to_numeric, errors="coerce")
    print(pd.DataFrame({"Media": it.mean().round(2), "DE": it.std().round(2),
                        "% acuerdo": (100 * (it >= 4).mean()).round(1)}).to_string())


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "respuestas.csv")
